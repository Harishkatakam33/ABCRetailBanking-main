export class Customer {
    constructor(
        public customerid: number, 
        public customername: string, 
        public customeremail: string,
        public customerphone
        ) {}
}