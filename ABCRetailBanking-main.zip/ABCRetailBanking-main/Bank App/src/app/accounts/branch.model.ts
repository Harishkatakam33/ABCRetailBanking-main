export class Branch {
    constructor(public branchName: string, public branchCode: string) {}
}