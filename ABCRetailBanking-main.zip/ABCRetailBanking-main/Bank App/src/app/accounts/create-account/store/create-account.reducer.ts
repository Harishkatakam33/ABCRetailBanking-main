import { Branch } from "../../branch.model";
import * as CreateAccountActions from './create-account.action'

export interface State {
    branchList: Branch[];
}

const initialState: State = {
    branchList: [new Branch('Vijaywada', 'ABC000001'),
                 new Branch('Hyderabad', 'ABC000002'),
                 new Branch('Chennai', 'ABC000003'),
                 new Branch('Kakinda', 'ABC000004'),
                 new Branch('Manglore', 'ABC000005'),
                 new Branch('Kottayam', 'ABC000006')
                ]
};

export function CreateAccountReducer (
    state: State = initialState,
    action: CreateAccountActions.CreateAccountActions
) {
    switch(action.type) {
        case CreateAccountActions.GET_BRANCH_LIST: 
            return {
                ...state,
            };
        default:
            return state;
    }
}