export class Payee {
    constructor(public name: string, public accountNumber: string) {
        
    }
}